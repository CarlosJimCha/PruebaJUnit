package ENDES_CJC.PruebaJUnit.cuentas;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

@DisplayName("Test de la clase Cuenta")
class CuentaTest {

	private static Cuenta ejCuenta;
	
	@BeforeAll
	static void setUpBeforeClass() throws Exception {
	}

	@AfterAll
	static void tearDownAfterClass() throws Exception {
	}

	@BeforeEach
	void setUp() throws Exception {
	}

	@AfterEach
	void tearDown() throws Exception {
	}

	@Test
	@DisplayName("Test al constructor de Cuenta")
	void testCuenta() {
		ejCuenta = new Cuenta("1","Pepe");
		assertEquals("1",ejCuenta.mNumero,"Error, Cuenta no funciona");
	}

	@Disabled
	@Test
	@DisplayName("Test al método ingresar")
	void testIngresar() throws IngresoNegativoException {
		fail("Not yet implemented"); // TODO
	}

	@Disabled
	@Test
	@DisplayName("Test al método retirar")
	void testRetirar() {
		fail("Not yet implemented"); // TODO
	}

	@Disabled
	@Test
	@DisplayName("Test al método getSaldo")
	void testGetSaldo() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	@DisplayName("Test al método addMovimiento")
	void testAddMovimiento() {
		
	}

}
