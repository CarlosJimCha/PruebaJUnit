package ENDES_CJC.PruebaJUnit.cuentas;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

@DisplayName("Test de la clase Movimiento")
class MovimientoTest {

	/*
	private static Cuenta c;
	private static double importe;
	private static String concepto;
	*/

	@Disabled
	@Test
	void testGetImporte() {
		fail("Not yet implemented"); // TODO
	}

	@Disabled
	@Test
	void testGetConcepto() {
		fail("Not yet implemented"); // TODO
	}

	@Disabled
	@Test
	void testSetConcepto() {
		fail("Not yet implemented"); // TODO
	}

	@Disabled
	@Test
	void testSetImporte() {
		fail("Not yet implemented"); // TODO
	}

}
